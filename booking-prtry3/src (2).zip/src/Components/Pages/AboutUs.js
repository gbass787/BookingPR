import React, { Component } from 'react';
import background from "../../Images/home.jpg";

class AboutUs extends Component {
  render() {
    return (
      <div>
          <h2>About Us</h2>
        </div>
    );
  }
}

export default AboutUs;