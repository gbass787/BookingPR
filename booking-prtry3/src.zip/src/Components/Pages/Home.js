import '../../Css/Home.css';
import '../../Css/AllComponents.css';
import React, { Component } from 'react';
import Image from 'react-bootstrap/Image';
import  Button  from 'react-bootstrap/Button';


class Home extends Component {
  render() {
    return (
      <div className='HomeContainer'>
            <span>Welcome to BOOKINGPR</span>
            <br/>
            <span>Most known artists are good, but not all good artists are known!</span>
            <br/>
            <Button variant="success" href="search">
              Search Bands
            </Button>
        
        
      </div>
    );
  }
}

export default Home;